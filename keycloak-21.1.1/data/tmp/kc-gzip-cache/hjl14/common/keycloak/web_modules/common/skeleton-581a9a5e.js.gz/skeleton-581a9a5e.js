var a=void 0;export{a as default};
//# sourceMappingURL=skeleton-581a9a5e.js.map
