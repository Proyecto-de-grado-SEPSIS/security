var a=void 0;export{a as default};
//# sourceMappingURL=truncate-249f9c8c.js.map
