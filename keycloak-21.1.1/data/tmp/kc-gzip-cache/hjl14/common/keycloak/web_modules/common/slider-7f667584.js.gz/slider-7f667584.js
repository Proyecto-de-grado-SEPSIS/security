var a=void 0;export{a as default};
//# sourceMappingURL=slider-7f667584.js.map
