var a=void 0;export{a as default};
//# sourceMappingURL=card-a904011f.js.map
