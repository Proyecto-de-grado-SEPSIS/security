var a=void 0;export{a as default};
//# sourceMappingURL=modal-box-b501f085.js.map
