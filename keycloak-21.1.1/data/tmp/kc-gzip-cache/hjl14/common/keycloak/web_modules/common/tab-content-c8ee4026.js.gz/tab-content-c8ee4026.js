var a=void 0;export{a as default};
//# sourceMappingURL=tab-content-c8ee4026.js.map
