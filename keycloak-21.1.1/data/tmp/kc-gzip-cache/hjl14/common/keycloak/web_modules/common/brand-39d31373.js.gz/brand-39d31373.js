var a=void 0;export{a as default};
//# sourceMappingURL=brand-39d31373.js.map
