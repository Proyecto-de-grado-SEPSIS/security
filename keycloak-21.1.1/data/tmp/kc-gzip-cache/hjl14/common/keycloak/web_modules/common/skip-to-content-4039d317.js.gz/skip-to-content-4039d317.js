var a=void 0;export{a as default};
//# sourceMappingURL=skip-to-content-4039d317.js.map
