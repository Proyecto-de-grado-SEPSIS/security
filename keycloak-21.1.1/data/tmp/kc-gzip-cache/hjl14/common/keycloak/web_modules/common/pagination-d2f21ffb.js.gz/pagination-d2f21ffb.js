var a=void 0;export{a as default};
//# sourceMappingURL=pagination-d2f21ffb.js.map
