var a=void 0;export{a as default};
//# sourceMappingURL=search-input-b6d2f4a8.js.map
