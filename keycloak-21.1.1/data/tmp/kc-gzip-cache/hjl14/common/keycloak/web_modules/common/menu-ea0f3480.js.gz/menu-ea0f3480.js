var a=void 0;export{a as default};
//# sourceMappingURL=menu-ea0f3480.js.map
