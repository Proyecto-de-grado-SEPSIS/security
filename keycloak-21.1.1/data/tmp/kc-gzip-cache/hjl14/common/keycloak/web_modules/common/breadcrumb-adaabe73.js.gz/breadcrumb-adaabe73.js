var a=void 0;export{a as default};
//# sourceMappingURL=breadcrumb-adaabe73.js.map
