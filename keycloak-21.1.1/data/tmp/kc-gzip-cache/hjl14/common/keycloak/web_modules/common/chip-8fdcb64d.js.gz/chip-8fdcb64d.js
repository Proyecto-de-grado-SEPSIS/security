var a=void 0;export{a as default};
//# sourceMappingURL=chip-8fdcb64d.js.map
