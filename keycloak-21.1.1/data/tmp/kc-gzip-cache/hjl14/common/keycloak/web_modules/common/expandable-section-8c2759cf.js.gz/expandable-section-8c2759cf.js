var a=void 0;export{a as default};
//# sourceMappingURL=expandable-section-8c2759cf.js.map
