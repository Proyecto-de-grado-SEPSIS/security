var a=void 0;export{a as default};
//# sourceMappingURL=calendar-month-29372728.js.map
