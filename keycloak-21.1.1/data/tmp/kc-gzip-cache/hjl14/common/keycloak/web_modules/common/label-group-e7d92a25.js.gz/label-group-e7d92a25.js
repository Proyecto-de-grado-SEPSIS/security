var a=void 0;export{a as default};
//# sourceMappingURL=label-group-e7d92a25.js.map
