var a=void 0;export{a as default};
//# sourceMappingURL=tabs-a09b599e.js.map
