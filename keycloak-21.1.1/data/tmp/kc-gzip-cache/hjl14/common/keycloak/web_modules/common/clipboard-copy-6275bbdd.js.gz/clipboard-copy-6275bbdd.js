var a=void 0;export{a as default};
//# sourceMappingURL=clipboard-copy-6275bbdd.js.map
