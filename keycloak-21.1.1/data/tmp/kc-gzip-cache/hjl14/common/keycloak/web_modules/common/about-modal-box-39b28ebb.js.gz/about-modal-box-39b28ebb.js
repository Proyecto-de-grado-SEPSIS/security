var a=void 0;export{a as default};
//# sourceMappingURL=about-modal-box-39b28ebb.js.map
