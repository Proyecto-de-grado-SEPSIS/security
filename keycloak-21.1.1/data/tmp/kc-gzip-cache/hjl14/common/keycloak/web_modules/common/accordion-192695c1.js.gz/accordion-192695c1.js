var a=void 0;export{a as default};
//# sourceMappingURL=accordion-192695c1.js.map
