var a=void 0;export{a as default};
//# sourceMappingURL=description-list-7d21c373.js.map
