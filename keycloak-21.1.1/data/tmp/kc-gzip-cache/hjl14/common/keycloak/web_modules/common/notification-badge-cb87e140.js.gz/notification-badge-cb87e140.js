var a=void 0;export{a as default};
//# sourceMappingURL=notification-badge-cb87e140.js.map
