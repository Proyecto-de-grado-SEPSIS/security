var a=void 0;export{a as default};
//# sourceMappingURL=sidebar-0550c4f9.js.map
