var a=void 0;export{a as default};
//# sourceMappingURL=back-to-top-9634345a.js.map
