var a=void 0;export{a as default};
//# sourceMappingURL=panel-0884a843.js.map
