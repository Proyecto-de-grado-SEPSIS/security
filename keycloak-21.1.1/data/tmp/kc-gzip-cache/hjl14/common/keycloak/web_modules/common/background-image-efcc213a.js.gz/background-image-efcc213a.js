var a=void 0;export{a as default};
//# sourceMappingURL=background-image-efcc213a.js.map
