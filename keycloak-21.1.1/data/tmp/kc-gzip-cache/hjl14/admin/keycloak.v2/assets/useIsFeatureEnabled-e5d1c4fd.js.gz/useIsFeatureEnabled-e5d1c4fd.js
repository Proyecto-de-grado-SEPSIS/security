import{R as l}from"./index-d2c499e7.js";var i=(e=>(e.DeclarativeUserProfile="DECLARATIVE_USER_PROFILE",e))(i||{});function c(){const{profileInfo:e}=l(),t=e?.experimentalFeatures??[],s=e?.previewFeatures??[],a=e?.disabledFeatures??[],n=[...t,...s].filter(r=>!a.includes(r));return function(u){return n.includes(u)}}export{i as F,c as u};
//# sourceMappingURL=useIsFeatureEnabled-e5d1c4fd.js.map
