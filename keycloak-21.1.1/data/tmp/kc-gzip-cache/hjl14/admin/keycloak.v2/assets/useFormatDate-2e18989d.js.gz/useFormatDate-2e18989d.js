import{ca as n}from"./index-d2c499e7.js";const s={dateStyle:"long",timeStyle:"short"};function l(){const{whoAmI:t}=n(),o=t.getLocale();return function(e,a){return e.toLocaleString(o,a)}}export{s as F,l as u};
//# sourceMappingURL=useFormatDate-2e18989d.js.map
