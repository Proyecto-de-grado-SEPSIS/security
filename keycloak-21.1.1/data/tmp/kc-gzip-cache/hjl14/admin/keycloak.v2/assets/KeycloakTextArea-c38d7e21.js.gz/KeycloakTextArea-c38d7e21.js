import{r as s,j as n,cF as x}from"./index-d2c499e7.js";const c=s.forwardRef(({onChange:r,...a},e)=>{const o=(p,t)=>r?.(t);return n.jsx(x,{...a,ref:e,onChange:o})});c.displayName="TextArea";export{c as K};
//# sourceMappingURL=KeycloakTextArea-c38d7e21.js.map
