import{z as s}from"./index-d2c499e7.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-c564b292.js.map
