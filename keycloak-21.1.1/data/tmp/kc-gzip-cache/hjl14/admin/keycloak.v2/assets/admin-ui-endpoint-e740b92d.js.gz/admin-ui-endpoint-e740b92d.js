import{a1 as t}from"./index-d2c499e7.js";import{j as n}from"./joinPath-55fd24bc.js";async function i(a,s,e){const o=await a.getAccessToken(),r=a.baseUrl;return await(await fetch(n(r,"admin/realms",a.realmName,s)+(e?"?"+new URLSearchParams(e):""),{method:"GET",headers:t(o)})).json()}export{i as f};
//# sourceMappingURL=admin-ui-endpoint-e740b92d.js.map
