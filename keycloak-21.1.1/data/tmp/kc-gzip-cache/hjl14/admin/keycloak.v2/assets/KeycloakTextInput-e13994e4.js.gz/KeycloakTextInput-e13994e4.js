import{r as n,j as s,aw as p}from"./index-d2c499e7.js";const x=n.forwardRef(({onChange:t,...a},r)=>{const e=(u,o)=>t?.(o);return s.jsx(p,{...a,ref:r,onChange:e})});x.displayName="TextInput";export{x as K};
//# sourceMappingURL=KeycloakTextInput-e13994e4.js.map
