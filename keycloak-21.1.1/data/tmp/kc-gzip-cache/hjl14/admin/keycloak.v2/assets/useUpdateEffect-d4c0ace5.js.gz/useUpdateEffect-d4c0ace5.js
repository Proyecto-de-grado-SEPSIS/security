import{r as t}from"./index-d2c499e7.js";function s(r,u){const e=t.useRef(!1);t.useEffect(()=>{if(e.current)return r();e.current=!0},u)}export{s as u};
//# sourceMappingURL=useUpdateEffect-d4c0ace5.js.map
