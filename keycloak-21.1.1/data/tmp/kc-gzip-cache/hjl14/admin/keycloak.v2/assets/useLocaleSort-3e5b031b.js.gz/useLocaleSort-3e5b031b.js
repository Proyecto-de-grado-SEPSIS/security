import{ca as u}from"./index-d2c499e7.js";function m(){const{whoAmI:o}=u();return function(a,e){const n=o.getLocale();return[...a].sort((s,l)=>{const r=e(s),c=e(l);return r===void 0||c===void 0?0:r.localeCompare(c,n)})}}const f=o=>t=>t[o];export{f as m,m as u};
//# sourceMappingURL=useLocaleSort-3e5b031b.js.map
